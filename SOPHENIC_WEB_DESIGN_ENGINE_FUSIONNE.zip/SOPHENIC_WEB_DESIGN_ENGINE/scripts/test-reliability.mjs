import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import vm from 'node:vm';
import { createRequire } from 'node:module';
import ts from 'typescript';
const nativeRequire = createRequire(import.meta.url);
const cache = new Map();
function load(file, mocks = {}, globals = {}, useCache = false) {
  file = path.resolve(file);
  if (useCache && cache.has(file)) return cache.get(file);
  const module = { exports: {} };
  const source = ts.transpileModule(fs.readFileSync(file, 'utf8'), { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS, esModuleInterop: true } }).outputText;
  const require = (id) => id in mocks ? mocks[id] : id.startsWith('.') ? load(path.resolve(path.dirname(file), `${id}.ts`), mocks, globals, true) : nativeRequire(id);
  vm.runInNewContext(source, { module, exports: module.exports, require, console, structuredClone, Date, URL, TextEncoder, Response, AbortSignal, setTimeout, clearTimeout, Buffer, process, ...globals }, { filename: file });
  if (useCache) cache.set(file, module.exports);
  return module.exports;
}
let checks = 0;
async function test(name, fn) { await fn(); checks++; console.log(`OK ${name}`); }
const brief = load('src/design/web-design/creative-brief.ts').heuristicWebDesignBrief('site gaming IA');
const templates = load('src/design/web-design/templates.ts');
const blueprint = load('src/design/web-design/template-mode.ts').customizeTemplate(templates.templateById('immersive-3d'), brief).blueprint;
const quality = load('src/design/web-design/quality.ts');
await test('fond sombre correctement reconnu', () => {
  const dark = structuredClone(blueprint); dark.visualStyle.colors[0] = '#000000';
  assert(!quality.evaluateWebDesignQuality(dark, brief).issues.some(x => x.message.includes('Brief sombre')));
  dark.visualStyle.colors[0] = '#FFFFFF';
  assert(quality.evaluateWebDesignQuality(dark, brief).issues.some(x => x.message.includes('Brief sombre')));
});
await test('section sans CTA ne reçoit pas les points du CTA accueil', () => {
  const no = structuredClone(blueprint); no.pages[0].sections = [{name:'Présentation',purpose:'Présentation'}];
  const yes = structuredClone(no); yes.pages[0].sections[0].name = 'CTA';
  assert(quality.evaluateWebDesignQuality(yes, brief).scores.conversion > quality.evaluateWebDesignQuality(no, brief).scores.conversion);
});
await test('une page et une police sans serif restent admissibles', () => {
  const page = structuredClone(blueprint); page.pages = [page.pages[0]];
  const issues = quality.evaluateWebDesignQuality(page, {...brief,premiumLevel:'ultra-premium'}).issues;
  assert(!issues.some(x => /Moins de 3 pages|sans typographie display serif/.test(x.message)));
});
const project = {schemaVersion:1,id:'p',name:'Projet',domain:'webdesign',plan:{},digital:{},product:{},updatedAt:'2026-01-01',revision:1};
const map = new Map();
const localStorage = { getItem:k=>map.get(k)||null, setItem:(k,v)=>map.set(k,v) };
const storage = (window) => load('src/design/storage.ts', {'./architecture':{syncArchitectureNavigation:x=>x}}, {window});
await test('quota stockage visible', async () => {
  const s = storage({localStorage:{...localStorage,setItem(){throw new Error('QuotaExceeded')}}});
  await assert.rejects(s.saveDesignProject(project),/QuotaExceeded/);
});
await test('sauvegarde desktop échouée sans faux succès navigateur', async () => {
  const s = storage({localStorage,sophenicDesktop:{workspace:{designSave:async()=>{throw new Error('disk full')}}}});
  await assert.rejects(s.saveDesignProject(project),/disk full/);
  assert.equal(map.size,0);
});
await test('JSON corrompu protégé contre écrasement', async () => {
  map.set('sophenic.design.projects.v1','broken');
  await assert.rejects(storage({localStorage}).saveDesignProject(project));
  assert.equal(map.get('sophenic.design.projects.v1'),'broken'); map.clear();
});
await test('écritures concurrentes sérialisées', async () => {
  const writes=[];
  const s=storage({localStorage,sophenicDesktop:{workspace:{designSave:async p=>{if(p.revision===1)await new Promise(r=>setTimeout(r,10));writes.push(p.revision);return p;}}}});
  await Promise.all([s.saveDesignProject(project),s.saveDesignProject({...project,revision:2})]);
  assert.deepEqual(writes,[1,2]);
});
await test('suppression desktop échouée remonte au client', async()=> {
  await assert.rejects(storage({localStorage,sophenicDesktop:{workspace:{designDelete:async()=>false}}}).deleteDesignProject('p'));
});
await test('transfert Code refuse un stockage plein', () => {
  const h=load('src/design/web-design/code-handoff.ts',{}, {window:{localStorage:{getItem:()=>null,setItem:()=>{throw new Error('quota')}}}});
  assert.throws(()=>h.saveCodeHandoff({id:'h',blueprint}),/quota/);
});
await test('commande dans Docker avec workspace seul et sans secrets transmis', () => {
  const terminal=load('electron/runtime/code-engine/safe-terminal.ts');
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'sophenic-security-'));
  try {
    const args=terminal.sandboxArguments('npm.cmd test',dir,'sophenic-test');
    assert(args.includes('--read-only')); assert(args.includes('--cap-drop=ALL'));
    assert.equal(args.filter(x=>x==='--mount').length,1); assert.equal(args.at(-1),'npm test');
    assert(!args.join(' ').includes('docker.sock'));
    assert.throws(()=>terminal.sandboxArguments('echo ok',path.parse(dir).root,'test'));
  } finally {fs.rmSync(dir,{recursive:true,force:true});}
});
await test('consentement absent ou refusé bloque les actions', async () => {
  const a=load('electron/runtime/code-engine/action-approval.ts');
  await assert.rejects(a.requireActionApproval('deploy','details'));
  a.setActionApprovalHandler(async()=>false); await assert.rejects(a.requireActionApproval('deploy','details'));
  a.setActionApprovalHandler(async()=>true); await a.requireActionApproval('deploy','details');
});
await test('quota Design bloque avant appel fournisseur', async () => {
  let called=false;
  const d=load('src/lib/server/design-completion.ts',{'./usage':{assertWithinLimits:async()=>{throw new Error('DAILY_TOKEN_LIMIT')},recordUsage:async()=>{}}},{fetch:async()=>{called=true}});
  await assert.rejects(d.designCompletion('u',{body:'{}'}),/DAILY_TOKEN_LIMIT/);assert.equal(called,false);
});
await test('consommation réelle enregistrée et délai appliqué', async () => {
  let record;
  const d=load('src/lib/server/design-completion.ts',{'./usage':{assertWithinLimits:async()=>{},recordUsage:async x=>{record=x}}},{fetch:async(url,init)=>{
    assert(init.signal);assert.equal(JSON.parse(init.body).max_tokens,8000);
    return new Response(JSON.stringify({model:'test',usage:{prompt_tokens:10,completion_tokens:20,cost:0.01}}));
  }});
  await d.designCompletion('u',{body:'{"model":"test"}'});
  assert.equal(record.promptTokens,10);assert.equal(record.completionTokens,20);assert.equal(record.costUsd,0.01);assert.equal(record.strict,true);
});
await test('échec comptabilisation ne produit pas un succès', async()=>{
  const d=load('src/lib/server/design-completion.ts',{'./usage':{assertWithinLimits:async()=>{},recordUsage:async()=>{throw new Error('db down')}}},{fetch:async()=>new Response(JSON.stringify({usage:{prompt_tokens:1,completion_tokens:2}}))});
  await assert.rejects(d.designCompletion('u',{body:'{}'}),/db down/);
});
console.log(`${checks} tests de régression : OK`);
