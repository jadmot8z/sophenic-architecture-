export type ActionApproval = (action: string, detail: string) => Promise<boolean>;
let handler: ActionApproval | undefined;
/** Installed only by the main process; model arguments cannot grant approval. */
export function setActionApprovalHandler(value: ActionApproval): void { handler = value; }
export async function requireActionApproval(action: string, detail: string): Promise<void> {
  if (!handler || !await handler(action, detail)) throw new Error(`Action refusée : ${action}.`);
}
