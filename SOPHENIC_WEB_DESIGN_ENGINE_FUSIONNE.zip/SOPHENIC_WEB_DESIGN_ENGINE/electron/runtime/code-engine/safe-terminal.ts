import { spawn } from "node:child_process";
import { randomUUID } from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { validateCommand } from "./security-guard";

export type TerminalShell = "auto" | "powershell" | "cmd" | "bash";
export type SafeCommandResult = { code: number; output: string; durationMs: number; shell: Exclude<TerminalShell, "auto"> };

/** Commands run inside a disposable container, never the desktop shell.
 * Only the selected workspace is mounted. Vault and host environment are not forwarded.
 * The workspace itself is writable and must not contain production secrets.
 */
export function sandboxArguments(command: string, cwd: string, name: string): string[] {
  validateCommand(command);
  const root = fs.realpathSync(cwd);
  if (root === path.parse(root).root || /[,\r\n]/.test(root)) throw new Error("Sélectionne un dossier de projet dédié pour le terminal.");
  const normalized = command.replace(/\bnpm\.cmd\b/g, "npm").replace(/\bnpx\.cmd\b/g, "npx");
  return ["run", "--rm", "--name", name, "--init", "--read-only", "--cap-drop=ALL", "--security-opt=no-new-privileges", "--pids-limit=256", "--memory=2g", "--cpus=2", "--tmpfs", "/tmp:rw,nosuid,size=512m", "--mount", `type=bind,source=${root},target=/workspace`, "--workdir", "/workspace", "--env", "HOME=/tmp/sophenic", "--env", "npm_config_cache=/tmp/npm-cache", "node:22-bookworm", "bash", "-lc", normalized];
}

export function runSafeCommand(command: string, cwd?: string, options: { shell?: TerminalShell; timeoutMs?: number; signal?: AbortSignal } = {}): Promise<SafeCommandResult> {
  if (options.signal?.aborted) return Promise.reject(new Error("Tâche annulée."));
  if (!cwd) return Promise.reject(new Error("Un dossier de projet est requis."));
  if (options.shell && !["auto", "bash"].includes(options.shell)) return Promise.reject(new Error("Le terminal isolé utilise Bash/Linux. Adapte la commande ; aucune exécution Windows automatique."));
  const started = Date.now();
  const name = `sophenic-${randomUUID()}`;
  const args = sandboxArguments(command, cwd, name);
  const timeoutMs = Math.max(1000, Math.min(options.timeoutMs || 120_000, 900_000));
  return new Promise((resolve, reject) => {
    let output = "";
    let settled = false;
    const child = spawn("docker", args, { windowsHide: true });
    const append = (chunk: Buffer | string) => { output = (output + chunk.toString()).slice(-80_000); };
    const finish = (code: number) => {
      if (settled) return;
      settled = true; clearTimeout(timer); options.signal?.removeEventListener("abort", abort);
      if (code === 125) append("\nDémarre Docker Desktop en mode conteneurs Linux, puis réessaie. Aucun repli sur le terminal hôte.");
      resolve({ code, output: output.trim(), durationMs: Date.now() - started, shell: "bash" });
    };
    const stopContainer = (code: number, message: string) => {
      if (settled) return;
      // Stop the container, not just the docker client (which leaves workloads running).
      const cleanup = spawn("docker", ["rm", "-f", name], { windowsHide: true, stdio: "ignore" });
      cleanup.once("error", () => undefined);
      child.kill(); append(message); finish(code);
    };
    const abort = () => stopContainer(130, "\nTâche annulée.");
    const timer = setTimeout(() => stopContainer(124, `\nCommande arrêtée après ${timeoutMs} ms.`), timeoutMs);
    options.signal?.addEventListener("abort", abort, { once: true });
    if (options.signal?.aborted) abort();
    child.stdout?.on("data", append); child.stderr?.on("data", append);
    child.once("error", () => { if (!settled) { settled = true; clearTimeout(timer); options.signal?.removeEventListener("abort", abort); reject(new Error("Docker est requis pour le terminal isolé. Installe et démarre Docker Desktop (Linux), puis réessaie.")); } });
    child.once("close", (code) => finish(code ?? 1));
  });
}
