# SOPHENIC — corrections du 8 septembre 2026

## Résultat livré

Archive complète du code source corrigé. Ce ZIP n'est pas un installateur Windows et n'inclut pas node_modules, les sorties de compilation ou des identifiants de service.

## Changements appliqués

- **Scores de design** : correction de la détection des fonds sombres et du bonus CTA attribué à une simple section. Un site d'une page et une police sans serif ne sont plus pénalisés par principe. Les scores sont présentés comme une évaluation indicative du plan, et non un audit du site exécuté.
- **Sauvegarde** : erreurs navigateur/desktop remontées, bouton Réessayer, écritures sérialisées, conservation des erreurs de lecture sans écraser un fichier corrompu, retrait de la troncature silencieuse à 100 projets. Les mutations successives utilisent immédiatement le dernier état. Une tentative de sauvegarde est faite à la sortie de l'écran ; fermer l'application avant sa fin reste à éviter.
- **Historique Web Design** : les versions existantes sont désormais accessibles dans cet écran, avec nom personnalisé, restauration, annuler et rétablir.
- **Comparaison** : boutons Voir avant / Voir après pour comparer la précédente proposition à la nouvelle durant la session. L'historique nommé sert à conserver les versions après fermeture.
- **Design vers Code** : choix React, Next.js, Shopify, WordPress ou HTML/CSS ; sauvegarde avant transfert ; ouverture du mode Code avec le brief prérempli. L'utilisateur envoie ensuite sa demande. Aucun déploiement n'est déclenché par le transfert.
- **IA Design web** : les routes ai, intent et vision partagent le contrôle de quota, un délai de 90 secondes, une limite de charge transmise au fournisseur et l'enregistrement des tokens/coûts retournés. Les erreurs de lecture des quotas ou d'écriture de consommation ne sont plus ignorées. Le moteur local Electron n'utilise pas ces routes et conserve son propre routage.
- **Terminal Code** : terminal.run et project.verify utilisent désormais un conteneur Linux Node 22 éphémère, avec un seul dossier projet monté, racine en lecture seule, limites de ressources, capacités retirées et sans transmission des secrets du coffre. Une annulation demande également la suppression du conteneur. Aucun repli automatique sur un shell Windows.
- **Accès aux fichiers** : contrôle de la cible réelle des liens symboliques afin de refuser les chemins qui sortent du dossier projet.
- **Actions externes du moteur Code** : confirmation native avant docker.run/compose, création de dépôt, push GitHub, déploiement Vercel et invocation de plugin. Un argument produit par le modèle ne peut pas accorder cette confirmation.
- **Tests** : nouvelle commande npm run test:reliability, intégrée à la suite existante.

## Installation et lancement sous Windows

1. Extraire le ZIP dans un nouveau dossier. Garder une copie de l'ancienne version et de ses données.
2. Installer les dépendances avec `npm ci`.
3. Démarrer Docker Desktop en mode **conteneurs Linux** pour utiliser le terminal Code. Le premier appel peut télécharger l'image `node:22-bookworm`.
4. Reprendre la configuration habituelle des services et lancer `npm run dev:desktop`.
5. Pour reconstruire l'installateur sur Windows : `npm run build:installer`.

Le terminal isolé utilise Bash et npm, pas PowerShell/cmd. Il nécessite l'accès à Docker et à l'image de base. Les installations supplémentaires doivent se faire dans le projet ou dans /tmp ; la racine du conteneur est en lecture seule. Les fichiers du dossier projet restent lisibles/modifiables par les commandes et le réseau du conteneur reste actif pour les téléchargements. Ne choisir qu'un dossier de travail dédié, sans secrets de production. Cette protection concerne le moteur Code ; les autres fonctions de contrôle du PC ne sont pas supprimées.

## Validation réalisée dans cet environnement

- Vérification des sources : réussie.
- Vérification TypeScript application + Electron : réussie.
- Suite existante SOPHENIC, Design, V8.1, V8.2 et Web Design : réussie.
- 14 tests de régression supplémentaires : réussis (scores, stockage plein/corrompu, erreurs desktop, concurrence d'écriture, transfert, arguments d'isolation, consentement, quota et comptabilisation).
- Build web de production : réussi. Des avertissements ESLint subsistent dans le projet.
- Compilation Electron : réussie.

Les tests des API utilisent des réponses simulées. L'exécution d'un vrai conteneur, les autorisations natives Windows, les services IA/OAuth et l'installation Windows ne sont pas validés ici. La vérification du rendu dans un navigateur et les parcours utilisateurs complets restent à réaliser. Les quotas reprennent le système existant : ce correctif ne met pas en place de réservation budgétaire transactionnelle entre plusieurs serveurs. Une consommation sans coût fournisseur est conservée avec un coût amont inconnu.

## Périmètre

Ce correctif traite la fiabilité et les parcours décrits ci-dessus. Il ne constitue pas une refonte générale : les fonctions avancées, les anciens scripts documentaires, le centre de connexions et les audits navigateur du moteur Code sont conservés. L'acceptation sélective de chaque modification de code et un nouveau tableau de bord de coût par tâche ne sont pas ajoutés dans cette version.
