import { assertWithinLimits, recordUsage } from "./usage";

/** One common accounting and timeout boundary for all cloud Design calls. */
export async function designCompletion(userId: string, init: RequestInit): Promise<Response> {
  await assertWithinLimits(userId);
  const text = typeof init.body === "string" ? init.body : "";
  if (new TextEncoder().encode(text).byteLength > 12_000_000) throw new Error("DESIGN_PAYLOAD_TOO_LARGE");
  const request = JSON.parse(text) as { model?: string; max_tokens?: number };
  const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
    ...init,
    body: JSON.stringify({ ...request, max_tokens: request.max_tokens || 8000 }),
    signal: AbortSignal.timeout(90_000)
  });
  if (response.ok) {
    const data = await response.clone().json() as { id?: string; model?: string; usage?: { prompt_tokens?: number; completion_tokens?: number; cost?: number } };
    const usage = data.usage;
    // Refuse to report success without metering: avoids silently bypassing quotas.
    if (!usage || !Number.isFinite(usage.prompt_tokens) || !Number.isFinite(usage.completion_tokens)) throw new Error("DESIGN_USAGE_UNAVAILABLE");
    await recordUsage({ userId, providerModel: data.model || request.model || "unknown", kind: "agent", promptTokens: Math.max(0, usage.prompt_tokens!), completionTokens: Math.max(0, usage.completion_tokens!), costUsd: Math.max(0, Number(usage.cost) || 0), upstreamCostUsd: usage.cost ?? null, generationId: data.id, strict: true });
  }
  return response;
}

export function designError(error: unknown): { error: string; status: number } {
  const message = error instanceof Error ? error.message : "Service Design indisponible.";
  if (/^(DAILY_TOKEN_LIMIT|MONTHLY_TOKEN_LIMIT|MONTHLY_COST_LIMIT)$/.test(message)) return { error: "Limite d'utilisation atteinte. Consulte ta consommation avant de réessayer.", status: 429 };
  if (message === "DESIGN_PAYLOAD_TOO_LARGE") return { error: "Projet trop volumineux pour cet appel IA.", status: 413 };
  if (error instanceof Error && ["TimeoutError", "AbortError"].includes(error.name)) return { error: "L'analyse a dépassé 90 secondes. Réessaie avec une demande plus courte.", status: 504 };
  if (message === "DESIGN_USAGE_UNAVAILABLE") return { error: "Le fournisseur n'a pas confirmé la consommation de cet appel. Réessaie plus tard.", status: 502 };
  return { error: "L'appel IA ou son enregistrement a échoué. Réessaie plus tard.", status: 502 };
}
