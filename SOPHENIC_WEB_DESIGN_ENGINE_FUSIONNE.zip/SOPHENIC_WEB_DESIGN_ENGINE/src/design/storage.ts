import type { DesignProject } from "./types";
import { syncArchitectureNavigation } from "./architecture";

const STORAGE_KEY = "sophenic.design.projects.v1";
const ACTIVE_KEY = "sophenic.design.active.v1";

function validProject(value: unknown): value is DesignProject {
  if (!value || typeof value !== "object" || Array.isArray(value)) return false;
  const row = value as Partial<DesignProject>;
  return row.schemaVersion === 1 && typeof row.id === "string" && typeof row.name === "string" && Boolean(row.plan && row.digital && row.product);
}

function normalizeProject(project: DesignProject): DesignProject {
  if (project.domain !== "architecture") return project;
  // Migration non destructive : on conserve les objets des anciens projets,
  // mais on leur ajoute la navigation V2 nécessaire au nouveau viewer.
  return syncArchitectureNavigation(project);
}

function browserList(): DesignProject[] {
  if (typeof window === "undefined") return [];
  const raw = window.localStorage.getItem(STORAGE_KEY);
  const parsed: unknown = raw ? JSON.parse(raw) : [];
  if (!Array.isArray(parsed) || !parsed.every(validProject)) throw new Error("Les projets enregistrés sont illisibles. Exportez vos données avant toute réinitialisation.");
  return parsed.map(normalizeProject).sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
}
function browserWrite(projects: DesignProject[]): void {
  if (typeof window === "undefined") throw new Error("Sauvegarde indisponible hors navigateur.");
  window.localStorage.setItem(STORAGE_KEY, JSON.stringify(projects));
}

export async function listDesignProjects(): Promise<DesignProject[]> {
  const desktop = typeof window !== "undefined" ? window.sophenicDesktop : undefined;
  if (desktop?.workspace.designList) {
    const rows = await desktop.workspace.designList();
    if (!Array.isArray(rows) || !rows.every(validProject)) throw new Error("Liste des projets invalide.");
    return rows.map(normalizeProject).sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
  }
  return browserList();
}

async function writeDesignProject(project: DesignProject): Promise<DesignProject> {
  const next = structuredClone(project);
  next.updatedAt = new Date().toISOString();
  const desktop = typeof window !== "undefined" ? window.sophenicDesktop : undefined;
  if (desktop?.workspace.designSave) {
    const saved = await desktop.workspace.designSave(next);
    if (!validProject(saved)) throw new Error("La sauvegarde n'a pas été confirmée.");
    return saved;
  }
  const local = browserList();
  browserWrite([next, ...local.filter((item) => item.id !== next.id)]);
  return next;
}

async function removeDesignProject(projectId: string): Promise<boolean> {
  const desktop = typeof window !== "undefined" ? window.sophenicDesktop : undefined;
  if (desktop?.workspace.designDelete) {
    const deleted = await desktop.workspace.designDelete(projectId);
    if (!deleted) throw new Error("La suppression n'a pas été confirmée.");
    return true;
  }
  browserWrite(browserList().filter((item) => item.id !== projectId));
  return true;
}

export function getActiveDesignProjectId(): string {
  if (typeof window === "undefined") return "";
  try { return window.localStorage.getItem(ACTIVE_KEY) || ""; } catch { return ""; }
}
export function setActiveDesignProjectId(projectId: string): void {
  if (typeof window === "undefined") return;
  try { if (projectId) window.localStorage.setItem(ACTIVE_KEY, projectId); else window.localStorage.removeItem(ACTIVE_KEY); } catch {}
}

let pendingWrite: Promise<unknown> = Promise.resolve();
export function saveDesignProject(project: DesignProject): Promise<DesignProject> {
  const snapshot = structuredClone(project);
  const task = pendingWrite.catch(() => undefined).then(() => writeDesignProject(snapshot));
  pendingWrite = task;
  return task;
}

export function deleteDesignProject(projectId: string): Promise<boolean> {
  const task = pendingWrite.catch(() => undefined).then(() => removeDesignProject(projectId));
  pendingWrite = task;
  return task;
}
