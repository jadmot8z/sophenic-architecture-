import type { DesignAssetSearchResult } from "./types";

export type AssetSelectionScore = { item: DesignAssetSearchResult; score: number; reasons: string[] };

const POSITIVE = ["photorealistic", "realistic", "pbr", "high quality", "interior", "furniture", "design", "modern", "contemporary", "luxury", "premium", "scanned"];
const NEGATIVE = ["low poly", "lowpoly", "voxel", "cartoon", "stylized", "anime", "minecraft", "blockout", "prototype", "placeholder"];

function normalized(value: string): string {
  return value.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
}

export function scoreDesignAsset(item: DesignAssetSearchResult, query: string): AssetSelectionScore {
  const terms = normalized(query).split(/[^a-z0-9]+/i).filter((term) => term.length > 2);
  const haystack = normalized(`${item.name} ${item.tags.join(" ")}`);
  const reasons: string[] = [];
  let score = 0;

  const matched = terms.filter((term) => haystack.includes(term));
  score += matched.length * 4.5;
  if (matched.length) reasons.push(`${matched.length} terme(s) du brief correspondent`);

  for (const token of POSITIVE) {
    if (haystack.includes(normalized(token))) { score += token === "photorealistic" || token === "realistic" ? 7 : 2.5; reasons.push(`signal qualité : ${token}`); }
  }
  for (const token of NEGATIVE) {
    if (haystack.includes(normalized(token))) { score -= token === "low poly" || token === "lowpoly" ? 14 : 9; reasons.push(`pénalité : ${token}`); }
  }

  if (item.staffPicked) { score += 12; reasons.push("Staff Pick Sketchfab"); }
  if (item.thumbnailUrl) score += 1.5;
  if (item.author) score += 1;
  if (item.license?.trim()) score += 2;
  if ((item.likeCount || 0) > 0) score += Math.min(9, Math.log10((item.likeCount || 0) + 1) * 3.5);
  if ((item.viewCount || 0) > 0) score += Math.min(6, Math.log10((item.viewCount || 0) + 1) * 1.4);

  const faces = item.faceCount || 0;
  const vertices = item.vertexCount || 0;
  const complexity = Math.max(faces, vertices / 2);
  if (complexity > 5_000 && complexity < 800_000) { score += 4; reasons.push("complexité 3D crédible"); }
  else if (complexity > 1_600_000) { score -= 4; reasons.push("asset très lourd"); }
  else if (complexity > 0 && complexity < 700) { score -= 8; reasons.push("géométrie très faible"); }

  if (/chair|sofa|bed|table|lamp|plant|wardrobe|cabinet|vanity|toilet|shower|rug/.test(normalized(query))) {
    const core = normalized(query).split(/\s+/).find((term) => /chair|sofa|bed|table|lamp|plant|wardrobe|cabinet|vanity|toilet|shower|rug/.test(term));
    if (core && !haystack.includes(core)) score -= 10;
  }

  return { item, score, reasons: reasons.slice(0, 8) };
}

/**
 * V7 ranking between an Asset Provider and the architecture editor.
 * Results without an explicit license or download permission are rejected.
 * Realistic/PBR/high-quality furniture is preferred while obvious low-poly,
 * cartoon or placeholder assets are strongly penalized.
 */
export function rankDesignAssets(results: DesignAssetSearchResult[], query: string): AssetSelectionScore[] {
  return results
    .filter((item) => item.downloadable && Boolean(item.license?.trim()))
    .map((item) => scoreDesignAsset(item, query))
    .sort((a, b) => b.score - a.score);
}

export function selectBestDesignAsset(results: DesignAssetSearchResult[], query: string): DesignAssetSearchResult | null {
  const ranked = rankDesignAssets(results, query);
  if (!ranked.length) return null;
  // A negative score means the result is a poor semantic/visual match. Prefer
  // SOPHENIC's premium procedural fallback over importing a visibly bad asset.
  return ranked[0].score >= 0 ? ranked[0].item : null;
}
