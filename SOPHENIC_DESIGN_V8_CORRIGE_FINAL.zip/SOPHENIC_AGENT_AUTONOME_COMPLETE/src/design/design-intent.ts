import { parseArchitectureBrief } from "./interior-brief";
import type { DesignArchitectureBrief, DesignIntentSummary, DesignProject, DesignReferenceAnalysis, DesignReferenceKind } from "./types";

const normalize = (value: string) => value.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
const uid = (prefix = "design-ref") => `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
const unique = <T,>(values: T[]) => [...new Set(values.filter((value): value is T => Boolean(value)))];

type HintRule = { pattern: RegExp; value: string };

const STYLE_RULES: HintRule[] = [
  { pattern: /palai|palace|royal|majest/, value: "palatial majestueux" },
  { pattern: /villa/, value: "villa contemporaine" },
  { pattern: /japandi/, value: "japandi" },
  { pattern: /minimal/, value: "minimaliste chaleureux" },
  { pattern: /mediterr|m[ée]diterran/, value: "méditerranéen contemporain" },
  { pattern: /classique|haussmann|traditional/, value: "classique raffiné" },
  { pattern: /moderne|contemporain/, value: "contemporain" }
];

const MATERIAL_RULES: HintRule[] = [
  { pattern: /travertin/, value: "Travertin ivoire" },
  { pattern: /marbre/, value: "Marbre Calacatta clair" },
  { pattern: /noyer/, value: "Noyer fumé" },
  { pattern: /ch[eê]ne|oak/, value: "Chêne naturel" },
  { pattern: /laiton|brass/, value: "Laiton brossé" },
  { pattern: /verre|glass/, value: "Verre extra-clair" },
  { pattern: /velours|velvet/, value: "Velours ivoire" },
  { pattern: /boucl[eé]/, value: "Bouclé sable" },
  { pattern: /pierre|stone/, value: "Pierre calcaire" },
  { pattern: /lin|linen/, value: "Lin ivoire" }
];

const PALETTE_RULES: HintRule[] = [
  { pattern: /ivoire|ivory|cr[eè]me|cream/, value: "#F3EEE6" },
  { pattern: /beige|sable|sand|taupe/, value: "#D7C8B4" },
  { pattern: /bois|noisette|caramel|brun chaud/, value: "#B69C7C" },
  { pattern: /noyer|cognac|terre cuite|terracotta/, value: "#73523C" },
  { pattern: /vert sauge|sage|olive/, value: "#6D7A68" },
  { pattern: /noir|anthracite|charcoal/, value: "#272925" },
  { pattern: /or|gold|laiton/, value: "#B08A52" }
];

const FURNITURE_RULES: HintRule[] = [
  { pattern: /canap|sofa/, value: "canapé premium" },
  { pattern: /fauteuil|armchair/, value: "fauteuil d’accent" },
  { pattern: /table basse|coffee table/, value: "table basse" },
  { pattern: /table a manger|table à manger|dining/, value: "table à manger" },
  { pattern: /lit|bed/, value: "lit haut de gamme" },
  { pattern: /suspension|luminaire|lamp/, value: "luminaire décoratif" },
  { pattern: /rideau|curtain/, value: "rideaux pleine hauteur" },
  { pattern: /tapis|rug/, value: "tapis de zone" },
  { pattern: /plante|plant/, value: "plantes d’intérieur" }
];

const ROOM_RULES: HintRule[] = [
  { pattern: /salon|living/, value: "Salon" },
  { pattern: /cuisine|kitchen/, value: "Cuisine" },
  { pattern: /salle a manger|salle à manger|dining/, value: "Salle à manger" },
  { pattern: /suite|master bedroom|bedroom|chambre/, value: "Suite parentale" },
  { pattern: /bureau|office/, value: "Bureau" },
  { pattern: /bath|salle de bain|salle d’eau/, value: "Salle de bain" },
  { pattern: /hall|entry|foyer/, value: "Hall" }
];

function collect(text: string, rules: HintRule[], limit = 8): string[] {
  const hits: string[] = [];
  for (const rule of rules) if (rule.pattern.test(text)) hits.push(rule.value);
  return unique(hits).slice(0, limit);
}

function inferAmbience(text: string): "day" | "evening" | "soft" {
  if (/soir|evening|night|nuit|tamis/.test(text)) return "evening";
  if (/jour|daylight|morning|sunlit|lumineux/.test(text)) return "day";
  return "soft";
}

function inferLuxury(text: string): DesignReferenceAnalysis["luxuryLevel"] {
  if (/palai|palace|ultra luxe|tr[eè]s haut de gamme|luxury|majest/.test(text)) return "luxury";
  if (/premium|haut de gamme|raffin|riche|d[eé]taill/.test(text)) return "rich";
  if (/minimal|sobre|simple/.test(text)) return "light";
  return "balanced";
}

function inferReferenceKind(name: string, text: string): DesignReferenceKind {
  const haystack = `${normalize(name)} ${text}`;
  if (/plan|floor plan|blueprint/.test(haystack)) return "plan";
  if (/facade|fa[cç]ade|exterieur|extérieur/.test(haystack)) return "facade";
  if (/material|mati[eè]re|marble|travertin|wood|texture/.test(haystack)) return "material";
  if (/interior|salon|bedroom|cuisine|living/.test(haystack)) return "interior";
  return "inspiration";
}

function inferProjectType(text: string): DesignIntentSummary["projectType"] {
  if (/palai|palace|royal|majest/.test(text)) return "palace";
  if (/villa/.test(text)) return "villa";
  if (/salon|cuisine|chambre|bathroom|interior|int[eé]rieur/.test(text)) return "interior";
  return "house";
}

export function analyzeReferenceText(input: { assetId?: string; name: string; analysis: string }): DesignReferenceAnalysis {
  const source = normalize(`${input.name} ${input.analysis}`);
  const styleHints = collect(source, STYLE_RULES);
  const materialHints = collect(source, MATERIAL_RULES);
  const paletteHints = collect(source, PALETTE_RULES, 6);
  const furnitureHints = collect(source, FURNITURE_RULES, 10);
  const roomHints = collect(source, ROOM_RULES, 8);
  return {
    id: uid("ref"),
    assetId: input.assetId || uid("asset"),
    name: input.name.trim().slice(0, 200) || "Référence",
    kind: inferReferenceKind(input.name, source),
    summary: input.analysis.trim().replace(/\s+/g, " ").slice(0, 360),
    styleHints,
    paletteHints,
    materialHints,
    furnitureHints,
    roomHints,
    ambience: inferAmbience(source),
    luxuryLevel: inferLuxury(source),
    createdAt: new Date().toISOString()
  };
}

function referenceDrivenGoals(references: DesignReferenceAnalysis[]): string[] {
  return unique(references.flatMap((reference) => [
    ...reference.furnitureHints.slice(0, 2).map((value) => `intégrer ${value}`),
    ...reference.styleHints.slice(0, 1).map((value) => `respecter l’esprit ${value}`)
  ])).slice(0, 10);
}

export function buildArchitectureIntent(project: DesignProject, instruction: string, references: DesignReferenceAnalysis[] = []): DesignIntentSummary {
  const brief: DesignArchitectureBrief = parseArchitectureBrief(instruction, project);
  const source = normalize(`${instruction} ${references.map((item) => `${item.name} ${item.summary} ${item.styleHints.join(" ")} ${item.materialHints.join(" ")}`).join(" ")}`);
  const projectType = inferProjectType(source);
  const palette = unique([...(projectType === "palace" ? ["#F5F0E8", "#DCC7A1", "#B08A52", "#73523C", "#272925"] : []), ...brief.palette, ...references.flatMap((item) => item.paletteHints)]).slice(0, 6);
  const materials = unique([...(projectType === "palace" ? ["Marbre Calacatta clair", "Laiton brossé"] : []), ...brief.materials, ...references.flatMap((item) => item.materialHints)]).slice(0, 8);
  const styles = unique([...references.flatMap((item) => item.styleHints), brief.style]);
  const inferredStyle = projectType === "palace"
    ? `${styles[0] || brief.style} monumental très haut de gamme`
    : projectType === "villa"
      ? `${styles[0] || brief.style} contemporain chaleureux`
      : styles[0] || brief.style;
  const finishLevel = projectType === "palace" ? "luxury" : references.some((item) => item.luxuryLevel === "luxury") ? "luxury" : brief.finishLevel;
  const ambience = references.find((item) => item.ambience)?.ambience || brief.ambience;
  const roomTargets = unique([...(brief.targetRooms || []), ...references.flatMap((item) => item.roomHints)]).slice(0, 10);
  const referenceSummary = references.slice(0, 6).map((item) => `${item.name} · ${item.kind}${item.styleHints[0] ? ` · ${item.styleHints[0]}` : ""}${item.materialHints.length ? ` · ${item.materialHints.slice(0, 2).join(", ")}` : ""}`);
  return {
    projectType,
    style: inferredStyle,
    finishLevel,
    palette,
    materials,
    ambience,
    goals: unique([...brief.priorities, ...referenceDrivenGoals(references)]).slice(0, 12),
    constraints: brief.constraints,
    roomTargets,
    referenceSummary,
    sketchfabStrategy: "strict",
    generatedAt: new Date().toISOString()
  };
}

export function designIntentSummary(intent: DesignIntentSummary): string {
  return `${intent.projectType} · ${intent.style} · finition ${intent.finishLevel} · ${intent.materials.slice(0, 4).join(", ")}`;
}
