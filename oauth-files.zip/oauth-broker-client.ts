import { runtimeEnv } from "./runtime-env";
import type { OAuthPluginId } from "./oauth-provider-registry";

export type BrokerSession = { session_id: string; poll_token: string; authorization_url: string; expires_at: string };
export type BrokerToken = {
  access_token: string;
  refresh_token?: string;
  expires_in?: number;
  scope?: string;
  token_type?: string;
  account?: string;
  extra?: Record<string, string>;
};

export class OAuthBrokerClient {
  readonly baseUrl: string;
  readonly distributionKey: string;

  constructor() {
    this.baseUrl = runtimeEnv("SOPHENIC_OAUTH_BROKER_URL").replace(/\/$/, "");
    this.distributionKey = runtimeEnv("SOPHENIC_OAUTH_BROKER_DISTRIBUTION_KEY");
  }

  get configured(): boolean { return /^https:\/\//i.test(this.baseUrl) || /^http:\/\/127\.0\.0\.1(?::\d+)?$/i.test(this.baseUrl); }

  private headers(): Record<string, string> {
    return { "Content-Type": "application/json", ...(this.distributionKey ? { "X-Sophenic-Distribution-Key": this.distributionKey } : {}) };
  }

  async createSession(input: { provider: OAuthPluginId; state: string; desktopCallback: string }): Promise<BrokerSession> {
    const response = await fetch(`${this.baseUrl}/v1/oauth/sessions`, {
      method: "POST", headers: this.headers(), body: JSON.stringify({ provider: input.provider, state: input.state, desktop_callback: input.desktopCallback }), signal: AbortSignal.timeout(20_000)
    });
    const payload = await response.json().catch(() => ({})) as Partial<BrokerSession> & { detail?: string };
    if (!response.ok || !payload.session_id || !payload.poll_token || !payload.authorization_url) throw new Error(payload.detail || "Le service de connexion SOPHENIC est momentanément indisponible.");
    return payload as BrokerSession;
  }

  async claim(session: BrokerSession, signal?: AbortSignal): Promise<BrokerToken> {
    const deadline = Math.min(Date.parse(session.expires_at) || Date.now() + 180_000, Date.now() + 180_000);
    while (Date.now() < deadline) {
      signal?.throwIfAborted();
      const requestSignal = signal ? AbortSignal.any([signal, AbortSignal.timeout(15_000)]) : AbortSignal.timeout(15_000);
      const response = await fetch(`${this.baseUrl}/v1/oauth/sessions/${encodeURIComponent(session.session_id)}`, {
        headers: { ...this.headers(), Authorization: `Bearer ${session.poll_token}` }, signal: requestSignal
      });
      const payload = await response.json().catch(() => ({})) as Record<string, unknown>;
      if (response.status === 202 || payload.status === "pending") { await new Promise((resolve) => setTimeout(resolve, 800)); continue; }
      if (!response.ok) throw new Error(String(payload.detail || payload.error || "La connexion OAuth a échoué."));
      if (typeof payload.access_token !== "string" || !payload.access_token) throw new Error("Le broker OAuth n’a renvoyé aucun jeton utilisable.");
      return payload as BrokerToken;
    }
    throw new Error("Le délai d’autorisation a expiré. Clique de nouveau sur Connecter.");
  }

  async refresh(provider: OAuthPluginId, refreshToken: string): Promise<BrokerToken> {
    const response = await fetch(`${this.baseUrl}/v1/oauth/refresh`, {
      method: "POST", headers: this.headers(), body: JSON.stringify({ provider, refresh_token: refreshToken }), signal: AbortSignal.timeout(30_000)
    });
    const payload = await response.json().catch(() => ({})) as BrokerToken & { detail?: string };
    if (!response.ok || !payload.access_token) throw new Error(payload.detail || "Le renouvellement OAuth a échoué.");
    return payload;
  }
}
